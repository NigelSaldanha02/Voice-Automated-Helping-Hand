# Household Objects Detection > 2025-11-03 7:18pm
https://universe.roboflow.com/voiceautomatedhelpinghand-fmskv/household-objects-detection-ggloy

Provided by a Roboflow user
License: CC BY 4.0

Dataset of common household objects usually found on tables for a Voice Automated Helping Hand - a robotic arm aimed at making picking and placing objects for elderly or mobility impaired individuals easier.

